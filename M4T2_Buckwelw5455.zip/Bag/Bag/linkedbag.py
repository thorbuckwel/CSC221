# -*- coding: utf-8 -*-
"""
Created on Thu Nov 15 15:22:53 2018

@author: buckwelw5455
"""

from baginterface import BagInterface
from node import Node

class LinkedBag(BagInterface):
    """A link-based bag implementation."""
    
    # Constructor
    def __init__(self, sourceCollection = None):
        """Set the initial state of self, which includes the
        contents of sourceCollection, it its present."""
        self._items = None
        self._size = 0
        if sourceCollection:
            for item in sourceCollection:
                self.add(item)
                
    def clear(self):
        """Make self become empty."""
        self.size = 0
                
    def __iter__(self):
        """Supports iteration over a view of self"""
        cursor = self._items
        while not cursor is None:
            yield cursor.data
            cursor = cursor.next
            
    def add(self, item):
        """Adds item of self."""
        self._items = Node(item, self._items)
        self._size += 1
        
    def remove(self, item):
        """Precondition: item is in self.
        Raises: KeyError if item is not in self.
        postcondition: item is removed from self."""
        
        # Check preconition and raise if necessary
        if not item in self:
            raise KeyError(str(item)+ " not in the bag")
        #Search for the nod containing the target item
        #probe wil point to the target nod. and trailer
        #will point to the one before it, if it exists
        probe = self._items
        trailer = None
        for targetItem in self:
            if targetItem == item:
                break
        trailer = probe
        probe = probe.next
        
        # Unhook the nod to be deleted, either the first one or the 
        # one thereafter
        if probe == self._items:
            self._items = self._items.next
        
        # Decrement logical size
        self._size -= 1