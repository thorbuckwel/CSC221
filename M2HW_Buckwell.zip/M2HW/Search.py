''' This function will load a list from a Pokemon csv file to be used
to display 151 of the pokemon in a sorted order. TODO come back to this
module later and give the user a choice on how to sort.'''
def GetList():
    # Load the list from the csv file
    pokemonList = open('pokemon.csv', 'r')
    # This is were the program will store just the identifers of the pokemon
    nameList = []
    # Used for the while loop
    number = 0

    # In each line in the List, the program will split the line at the ,s then only
    # add suscript 1 of the line since it is the identifer to the nameList
    for line in pokemonList:
        line = line.split(',')
        nameList.append(line[1])
    
    # Since the first line is the table heading go ahead and delete it
    del nameList[0]
    # A sorted list is always better
    nameList.sort()

    print('The Pokemon are:')

    # Only want to display the first 151 of the list. Instead of only having one name per line the
    # program will print 5 per line so it is a little more formatted
    while number in range(151):        
        print(nameList[number],', ',nameList[number +1], ',', nameList[number +2], ', ', nameList[number +3], ', ', nameList[number +4])
        number = number + 5

''' This function accepts a string that a user is looking for. It uses a dictonary
that used the Pokemon identifier as a key and then adds a list of values for that
Pokemon as a list in the values spot.'''
def SearchList(sentName):
    pokemonList = open('pokemon.csv', 'r')
    nameList = {}

    # This goes through the pokemonList and adds to the dictonary
    for line in pokemonList:
        line = line.split(',')
        nameList[line[1]] = [line[2],line[1],line[3],line[4]]

    # Remove the first entry since it is the column names
    del nameList['identifier']

    # Set for a table view
    print('ID {0:10} Name {0:10} Height {0:10} Weight'.format(''))

    # Convert the string to lower
    sentName = sentName.lower()

    # Search the dictonary for the Pokemon that matches or is close and then print.
    for name, value in nameList.items():
        if sentName in name:
            print('{0:12}{1:20}{2:18}{3:1}'.format(value[0],value[1],value[2],value[3]))
