from Menu import *
from Search import *

# CSC221
# M2HW_Buckwell
# Goal: [Bronze | Silver | Gold]

"""
Author: William Buckwell
This program will uses a csv file to get Pokemon information
"""

def main():
    again = 'y'

    while again == 'y':
        # Give the user a menu to choose from
        choice = ShowMenu()

        # Determine the useres choice
        if choice == 1:
            pokemon = GetList() # Get and print 151 pokemone           
        elif choice == 2:
            name = input('What name would you like the search? => ')
            pokemon = SearchList(name) # Search a list for pokemon that mathc or are close

        # Ask the user if they would like to do another search
        again = input('Do another search? Y/N => ')
        agian = again.lower()

if __name__ == "__main__":
    main()
