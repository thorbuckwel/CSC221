''' Display this menu for the user to make their choice. More choices
can be add to this menu'''
def ShowMenu():
    print('Choose from the list below.')
    print('1. List all Pokemon.')
    print('2. Pokemon Search.')

    return int(input('1/2 => '))
