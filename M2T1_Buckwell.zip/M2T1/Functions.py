''' This function will check for vowels in a string and then
return a list of vowels found'''
def Has_Which_Vowels(userInput):
    # The list vowels
    vowels = ['a', 'e', 'i', 'o', 'u']
    # List to hold the vowels that were found
    vowelsUsed = []

    # The first loop loops through the list of vowels
    for vowel in vowels:
        # The second loop loops through the string and compares
        # If there is a match then add to the vowelsUsed List
        for letter in userInput:
            if letter == vowel:
                vowelsUsed.append(letter)

    # Return the list
    return vowelsUsed
            
''' This function will check for letters the user want to search for
in a given string then returns the results.'''
def Has_Which_Letters(userInput, letters):
    # List to hold a letters found the user is searching for
    lettersFound = []

    # The first loop loops through the list of letters the user is searching for
    for letter in letters:
        # The second loop loops through the string and compares
        # If there is a match then add to the lettersFound List
        for value in userInput:
            if value == letter:
                lettersFound.append(value)

    # Return the list
    return lettersFound
