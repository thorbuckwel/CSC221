import Menu
import Functions

# CSC221
# M2T1_Buckwell
# Goal: [Bronze | Silver | Gold]

"""
Author: William Buckwell
This program will let you determine what vowels or letters are in a string
"""

def main():

    # Show the user the menu to choose from
    userChoice = Menu.GetMenu()

    
    if userChoice == 1: # If they want to see what vowels
        print('What is the sentance?')
        userInput = input('')
        Functions.Has_Which_Vowels (userInput)
    elif userChoice == 2: # If they want to search certian letters
        print('What is the sentance?')
        userInput = input('')
        print('What letters to test for?')
        letters = input('')
        Functions.Has_Which_Letters(userInput, letters)

if __name__ == "__main__":
    main()

