from Functions import *

def test_Has_Which_Vowels():
    vowelsUsed = Has_Which_Vowels('This is a test')
    test = ['a', 'e', 'i', 'i']

    assert vowelsUsed == test

def test_Has_Which_Vowels():
    vowelsUsed = Has_Which_Vowels('Ths s  tst')

    assert vowelsUsed == []

def test_Has_Which_Vowels():
    vowelsUsed = Has_Which_Vowels('tatetitotu')

    assert vowelsUsed == ['a', 'e', 'i', 'o', 'u']  

def test_Has_Which_Vowels():
    vowelsUsed = Has_Which_Vowels('')

    assert vowelsUsed == []

def test_Has_Which_Letters():
    lettersUsed = Has_Which_Letters('This is a test', 'tia')
    
    assert lettersUsed == ['t', 't', 'i', 'i', 'a']

def test_Has_Which_Letters():
    lettersUsed = Has_Which_Letters('This is a test', 'uln')

    assert lettersUsed == []

def test_Has_Which_Letters():
    lettersUsed = Has_Which_Letters('This is a test', 'qtpiva')

    assert lettersUsed == ['t', 't', 'i', 'i', 'a']

def test_Has_Which_Letters():
    lettersUsed =Has_Which_Letters('This is a test', '')

    assert lettersUsed == []

