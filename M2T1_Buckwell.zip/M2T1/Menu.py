
def GetMenu():
    # Gives the user a menu to chose from and returns the choice
    print('1. Determine which vowels are in a sentance.')
    print('2. Determine if a sentance has certian letters.')
    choice = int(input('1 or 2 => '))
    return choice
