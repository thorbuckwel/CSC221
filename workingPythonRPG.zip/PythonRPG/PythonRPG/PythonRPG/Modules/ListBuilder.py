# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:43:05 2018

@author: buckwelw5455
"""
from Classes.Mobs import *
from Classes.Rooms import *
from Classes.Weapons import *
import random

def BuildAList(rows, table, mobs = None, items = None):
    ''' This Function will build all the List the the game will need to run. It determines
        what table is being used so that it knows what Class of objects needs to be build
        Each has it own tables to return.

        The room list needs the other two list since there will be random Mobs and Items that
        can be assigned to each room.

        Args:
            rows (Information pulled from tables Lists?)
            table (string)
            mobs (List of Mobs) : If passed in, needed for rooms
            items (List of items) : If passed in, needed for rooms

        Return:
            List : Type depends on Table name '''

    if table == 'Mobs':
        mobList = []
        for row in rows:
            mobList.append(Mobs(row[0], row[1], row[2], row[3], row[4]))
        return mobList        
       
    if table == 'Weapons':
        itemList = []
        for row in rows:
            itemList.append(Weapons(row[0], row[1], row[2], row[3], row[4]))
        return itemList

    if table == 'Rooms':
        roomList = []
        for row in rows:
            random.shuffle(mobs)    # The only random method that I could get to work right
            mob = mobs[0]
            random.shuffle(items)
            item = items[0]

            if row[0] == 101: # For now only the starting room will have a weapon
               roomList.append(Rooms(row[0], row[1], row[2], row[3], mob, item))
            else:
                roomList.append(Rooms(row[0], row[1], row[2], row[3], mob))
        return roomList
        
        