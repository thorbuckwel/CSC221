# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:20:41 2018

@author: buckwelw5455
"""

from Modules.StandardMessages import MakeNewLine
from Modules.UpdateClassStats import AddClassStats

def DetermineRace():
    ''' This Function ask the use for a race and class, it then determines what starting 
        stats the player has by race. Then it passes this information along with the 
        players class choice to determine the final stats by class
        
        Args:
            None
            
        Return:
            race (Full name of Race)
            pClass (Full name of class)
            hp (Calculated hp)
            mp (Calculated mp)
            ac (Calculated ac)'''

    race = input('Human/Elf/Dwarf => ')
    MakeNewLine()
    
    pClass = input('Warrior/Mage/Smith => ')
    MakeNewLine()

    if race == 'h':        
        race = 'Human'
        pClass, hp, mp, ac = AddClassStats(pClass, 10, 5, 8)
        return race, pClass, hp, mp, ac

    if race == 'e':        
        race = 'Elf'
        pClass, hp, mp, ac = AddClassStats(pClass, 8, 10, 8)
        return race, pClass, hp, mp, ac

    if race == 'd':        
        race = 'Dwarf'
        pClass, hp, mp, ac = AddClassStats(pClass, 10, 3, 10)
        return race, pClass, hp, mp, ac

