# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:20:41 2018

@author: buckwelw5455
"""
from Modules.StandardMessages import MakeNewLine
def DisplayRoom(rooms, player):
    ''' Display the room the player is in. This method needs all the List
        and the player object to determine the correct information is
        provided to the user.
        
        Searchs the rooms list to match a room to the players current location, then
        it searhc the lists in the room to determine if there is anything in the room
        and prints all the information

        Args:
            rooms (List of Rooms)
            player (Player Object
        
        Void Return ''' 
    
    
    for room in rooms:
        if room.RoomID == player.CurrentLoaction:
            print(room.Title)
            print(room.descr)
            MakeNewLine()
            for mob in room.Mobs:
                print(mob.MobName)
            for item in room.Items:
                print(item.Name)

    MakeNewLine()
