# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:20:41 2018

@author: buckwelw5455
"""

def AddClassStats(pClass, hp, mp, ac):
    ''' This Function  accept stat values then add or subtract from them depending 
        on the class that the user has picked
        
        Args:
            pClass (user string)
            hp (players hp stat from race)
            mp (players mp stat from race)
            ac (players ac stat from race)
            
        Return:
            pClass (Full name of class)
            hp (Calculated hp)
            mp (Calculated mp)
            ac (Calculated ac)'''

    if pClass == 'w':
        pClass = 'Warrior'
        hp += 5
        ac += 1
        return pClass, hp, mp, ac

    if pClass == 'm':
        pClass = 'Mage'
        hp += 5
        ac += 1
        return pClass, hp, mp, ac

    if pClass == 's':
        pClass = 'Smith'
        hp += 5
        ac += 3
        mp -= 5
        return pClass, hp, mp, ac