# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:20:41 2018

@author: buckwelw5455
"""

from Modules.MakePlayer import createPlayer
from DataBase.PythonRPGDataBase import LoadPlayer
from Modules.StandardMessages import *

def Welcome():
    ''' This Function will run a loop asking the user if they are new or not. It will
        loop back if the user puts in an incorrect answer
        
        Args:
            None
        
        Void Return'''

    correctAnswer = 'n'

    while correctAnswer == 'n':

        WelcomeMessage()

        answer = input("Are you a new player? Y/N => ")
        MakeNewLine()

        if answer.lower() == 'y':
            player = createPlayer()
            correctAnswer = 'y'
            return player
        elif answer.lower() == 'n':
            correctAnswer = 'y'
            return LoadPlayer(answer)
        else:
            BadChoice()
