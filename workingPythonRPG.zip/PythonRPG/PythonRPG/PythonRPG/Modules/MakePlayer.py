# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:20:41 2018

@author: buckwelw5455
"""

from Modules.StandardMessages import Classes, Races, MakeNewLine
from Classes.Player import Player
from DataBase.PythonRPGDataBase import SavePlayer, create_connection
from Modules.UpdateRaceStats import DetermineRace


def createPlayer():
    ''' This Function gets the wanted players name and then calls another
        Function to determine the players stats from the users inputs. It 
        will then build a Player object from the return information

        It will also send the Player object to the SavePlayer Function

        Args:
            None

        Void Return'''
    
    name = input('What will be your name? ')
    MakeNewLine()

    TempPlayer = DetermineRace()

    player = Player(name, TempPlayer[0], TempPlayer[1], TempPlayer[2], TempPlayer[3], TempPlayer[4], 101)

    SavePlayer(player)

    return player



