# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:20:41 2018

@author: buckwelw5455
"""

def Races():
    # Prints the race menu
    Races = ['Choose a Race', 'Human', 'Elf', 'Dwarf']
    for string in Races:
        print(string)

def Classes():
    # Prints the classes menu
    Class('Choose a Class', 'Warrior', 'Mage', 'Smith')
    for string in Class:
        print(string)

def WelcomeMessage():
    # Prints the welcome text
     print("Welcome to the PythonRPG")
     print("This is a simple game to demo python code with SqLite database")
     print("")
     print("")

def BadChoice():
    # Used for any bad choices from the user (for now)
    print('Not a Valid Choice!')
    print('')

def MakeNewLine():
    # used when needing to seperate lines of text
    print('')