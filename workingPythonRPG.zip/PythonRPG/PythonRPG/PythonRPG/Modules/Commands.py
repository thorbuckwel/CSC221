# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:20:41 2018

@author: buckwelw5455
"""
import Classes.Player

def DetermineCommands(playerInput, mobs, items, rooms, player):
    ''' This Function was one of the hardes to do. Since Python does not seem to have a Switch-Case was
        forced to use a long if-elif statement. This Function will determine what command playerInput [0]
        the user is trying to use. From moving to getting and dropping items.

        The get and drop command require finding the room the user is in, looking in the room's list or players 
        inventory for the name of the object (which is in playerInput [1]). they then remove the object from the proper
        list and adds it to the other list.
    
        Other commands are a little more self explaining

        Args:
            playerInput (List of strings)
            rooms (List of Rooms)
            player (Player object)

        Void Return'''

    if len(playerInput) == 1 and str(playerInput) == "['n']":
        player.CurrentLoaction = Classes.Player.Player.Move(player,'n', rooms)
    elif len(playerInput) == 1 and str(playerInput) == "['s']":
        player.CurrentLoaction = Classes.Player.Player.Move(player,'s', rooms)
    elif playerInput[0] == 'get':
        for room in rooms:
            if room.RoomID == player.CurrentLoaction:
                for item in room.Items:
                    if item.Name.lower() == playerInput[1]:
                        room.Items.remove(item)
                        player.Inventory.append(item)
    elif playerInput[0] == 'drop':
        for item in player.Inventory:
            if item.Name.lower() == playerInput[1]:
                player.Inventory.remove(item)
                for room in rooms:
                    if room.RoomID == player.CurrentLoaction:
                        room.Items.append(item)
    elif playerInput[0] == 'inventory':
        print('')
        print('You have --')
        for item in player.Inventory:
            print(item.Name)
            print('')
        print('')