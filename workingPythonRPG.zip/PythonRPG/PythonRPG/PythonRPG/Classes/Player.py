# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:44:09 2018

@author: buckwelw5455
"""

class Player:
    def __init__(self, name, race, pclass, hp, mp, ac, currentLocation, inventory = None, level = None):
        # inventory and level are = None so this can be used as an overload.
        # if something gets passed in then it will be used.
        self.Name = name
        self.Race = race
        self.PClass = pclass
        self.HP = hp
        self.MP = mp
        self.AC = ac
        self.CurrentLoaction = currentLocation
            
        if level == None:
            self.Level = 1
        else:
            self.Level = level            
        
            
        if inventory == None:
            self.Inventory = []
        else:
            self.Inventory = inventory

    def Move(this, dir, rooms):
        ''' This Function allow the user to move through the game. It first
            Determines which way the user wanted to go, then makes sure it is
            not the last room in the list. It gets the players CurrentLocation 
            and adds or subtacts 1 from the room's ID and assigns it as the 
            new currentLocation.

            Args:
                this (Player object)
                dir (string)
                rooms (List of Rooms)

            Return:
                currentLoaction (int)'''
        
        if dir == 'n':
            if this.CurrentLoaction != 105:
                currentLocation = this.CurrentLoaction + 1
                print('')
                return currentLocation
            else:
                print('NOTHING NORTH!')
                print('')
                return this.CurrentLoaction

        if dir == 's':
            if this.CurrentLoaction != 101:
                currentLocation = this.CurrentLoaction - 1
                print('')
                return currentLocation
            else:
                print('NOTHING SOUTH!')
                print('')
                return this.CurrentLoaction
                
        
        
            
        

    