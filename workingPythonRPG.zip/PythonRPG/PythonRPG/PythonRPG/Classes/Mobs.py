# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:44:09 2018

@author: buckwelw5455
"""

class Mobs:
    def __init__(self, id, name, description, hp, ac):
        self.MobID = id
        self.MobName = name
        self.Descr = description
        self.HP = hp
        self.AC = ac
        