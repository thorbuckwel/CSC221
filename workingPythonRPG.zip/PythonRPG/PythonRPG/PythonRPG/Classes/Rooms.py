# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:44:09 2018

@author: buckwelw5455
"""

class Rooms:
    def __init__(self, id, title, description, exits, mob = None, item = None):
        # mob and item are = None so this can be used as an overload.
        # if something gets passed in then it will be used.
        self.RoomID = id
        self.Title = title
        self.descr = description
        self.Exits = exits
        
        if mob == None:
            self.Mobs = []
        else:
            self.Mobs = [mob]
        
        if item == None:
            self.Items = []
        else:
            self.Items = [item]