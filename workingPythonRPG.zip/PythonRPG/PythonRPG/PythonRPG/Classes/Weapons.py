# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:44:09 2018

@author: buckwelw5455
"""

class Weapons:
    def __init__(self, id, name, damType, price, damage):
        self.WeaponID = id
        self.Name = name
        self.DamType = damType
        self.Price = price
        self.Damage = damage