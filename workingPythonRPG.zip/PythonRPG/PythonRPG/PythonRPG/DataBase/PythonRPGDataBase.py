# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:06:21 2018

@author: buckwelw5455
"""
import Modules.ListBuilder
import sqlite3
from sqlite3 import Error
import Classes.Player

def create_connection(PythonRPGDB):
    ''' This Function is used to create a connection to the Database

        Arg:
            PythonRPGDB (Database)

        Return:
            conn (connection)
            None (If there is an error)'''
    try:
        conn = sqlite3.connect(PythonRPGDB)
        return conn
    except Error as e:
        print(e)
        
    return None

def SelectFromTable(conn, table, mobs = None, items = None):
    ''' This Function selects all information from the correct table and then it
        calls the BuildAList Function from another Module to built a list.

        Args:
            conn (DataBase connection)
            table (Name of table to get the information from)
            mobs (List of mobs) : Only used to build a list of rooms, will be passed
            items (List of items) : Only used to build a list of rooms, will be passed

        Return:
            objectList (A List of objects) : The type depends on the table used'''

    cur = conn.cursor()
    query = 'SELECT * FROM {}'.format(table)
    cur.execute(query)
    
    rows = cur.fetchall()
    cur.close()
    # Needs to pass all gathered information to build the list
    objectList = Modules.ListBuilder.BuildAList(rows, table, mobs, items)
    
    return objectList

def SavePlayer(player):
    ''' This Function saves the player object into a database. This needs more work to validate the new
        user name so there are not any doubles. 
        
        It creates a connection to the database. It also has a placeholder for the a new player's inventory
        since they will have nothing and the database will not save a list. This will be repersented with 'n'.
        
        Args:
            player (PLayer Object)

        Void Return'''
    #TODO search the database to ensure the name does not already exist
    conn = create_connection('PythonRPGDB.db')
    placeHolder = 'n'
    thisInvent = ','.join(placeholder for unused in player.Inventory)
    if thisInven == "":
        thisInven = placeHolder
    cur = conn.cursor()
    cur.execute('''INSERT INTO Players(Name,Race,Class,Level, HitPoints, ManaPoints, ArmorClass, Inventory, CurrentLocation) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'''\
                    , (player.Name, player.Race, player.PClass, player.Level, player.HP, player.MP, player.AC, thisInven, player.CurrentLoaction))
    conn.commit()
    cur.close()

def LoadPlayer(playerName):
    ''' This Function connects to the database and retreives all records from the Players
        table. It has nested loops since the first past will be a list of list. The Inner loop
        will loop through the fields for the user name.

        If the user has an inventory with items in it then it will load them. If id does not then
        remove the placeholder and reset the varaible 'inventory' to a List

        Args:
            playerName (string)

        Void Return '''
     #TODO put in code to check to make sure the players name is in the database
    list = []
    name = input("What will be your name? > ")
    conn = create_connection('PythonRPGDB.db')
    cur = conn.cursor()
    cur.execute('''SELECT * FROM Players''' )
    data = cur.fetchall()
    for row in data:
        for row2 in row:
            list.append(row2)

    if list[7] == 'n':
        inventory = []
        #TODO Determine where to create the object to load into the inventory from the string.
        return Classes.Player.Player(list[0], list[1], list[2], list[4], list[5], list[6], list[8], inventory, list[3])
    else:
        return Classes.Player.Player(list[0], list[1], list[2], list[4], list[5], list[6], list[8], list[7], list[3])

    cur.close()

    