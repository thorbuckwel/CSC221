# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:20:41 2018

@author: buckwelw5455
"""
from DataBase.PythonRPGDataBase import create_connection, SelectFromTable
from Modules.WelcomeScreen import Welcome
from Modules.RoomDisplay import DisplayRoom
from Modules.Commands import DetermineCommands
from Modules.StandardMessages import MakeNewLine
import Classes.Player

# Create the connecton to the Database to load the following List
conn = create_connection('PythonRPGDB.db')

# Each List calls the same Function but passes the table name that the items live in
mobs = list(SelectFromTable(conn, 'Mobs'))
items = list(SelectFromTable(conn, 'Weapons'))
rooms = list(SelectFromTable(conn, 'Rooms', mobs, items))

# Call the Welcome Module to determine if a new or returning player and create the player object
player = Welcome()
MakeNewLine()   # Simple method for a new line to seperate line

gameContinue = 'y' # Sentry for the While loop

# The While loop will keep the game running until the Sentry is changed buy the user 
# typing exit to quit the game
while gameContinue == 'y':
   
    #TODO Add Line Comments or Doc Comments

    # Display the rooms information
    DisplayRoom(rooms, player)

    playerInput = input("=> ")
    # Need to split the users input to determine what action needs to be taken
    playerInput = playerInput.lower().split()
    
    #TODO Add a Help command
    # After Getting the users input figure out what needs to be done
    DetermineCommands(playerInput, mobs, items, rooms, player)