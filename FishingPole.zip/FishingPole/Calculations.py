import math

def CalculatePoleAndBox(poleLength, boxLength, boxWidth):
    ''' This Function uses the math lib and uses the Pythagorean formula to determine if the fishing
    pole will fit in the box the user has'''
    
    thisSum = pow(boxLength, 2) + pow(boxWidth, 2)
    poleValue = pow(poleLength, 2)
    
    if thisSum >= poleValue:
        print('The fishing pole will fit in the box you have.')
    else:
        print('The fishing pole will NOT fit in the box you have.')

def CalculatePoleAndMax(poleLength, maxLength):
    ''' This Function uses the math lib and uses the Pythagorean formula to determine the size
        of a box the user would need for the fishing pole while knowing the pole size and the max
        box height that get be carried on the bus.'''

    boxLength = maxLength
    boxWidth = 0

    if poleLength < maxLength:
        print('The fishing pole will fit as is.')
    else:
        boxWidth = pow(poleLength, 2) - pow(boxLength, 2)
        boxWidth = math.sqrt(boxWidth)
        if boxWidth <= boxLength:
            print('The box your pole will fit in to get on the bus is {} foot in height and {} foot wide'.format(boxLength, boxWidth))
            print('or..{} foot in height and {} foot wide.'.format(boxWidth,boxLength))
        else:
            print('TODO does not fit')
    

def FindSmallestBox(poleLength):
    ''' This Function uses the math lib and uses the Pythagorean formula to determine the smallest box
    that the box will fit in and still meet the max limit for the bus.'''

    poleSquared = pow(poleLength, 2)
    boxLength = 0
    boxWidth = 0
    sidesSquared = poleSquared

    print(sidesSquared)

    ''' Starting at 0 for both length and width, step through an do the math. the first length and
    wide that the pole will fit is the smallest box that the pole will fit in'''
    for x in range(poleLength):
        for y in range(poleLength):
            
            totalSpace = pow(x, 2) + pow(y, 2)
            print(totalSpace)

            if totalSpace >= sidesSquared:
                boxLength = x
                boxWidth = y

                break

    print('The smallest box your pole will fit in is {} foot in height and {} foot wide, or..'.format(x,y))
    print('{} foot in height and {} foot wide.'.format(y,x))
    

    

    
