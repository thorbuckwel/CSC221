from StandardMessages import *
from Calculations import *

""" 
CSC221
M1T1_Buckwell
Goal : Gold
Author: William Buckwell
A program to determine if you can get a fishing pole on a bus that only allow packages of 4 feet.
"""
def main():
    
    
    tryAgain = 'y'  # Used to determine if the program should keep going

    
    while tryAgain == 'y':

        # Shoe menu and store the users choice
        userChoice = ShowMenu()

        # Determine what the user wants to do and then run calculations
        if userChoice == 'd':
            # Get the users information
            poleLength, boxLength, boxWidth = GetPoleAndBoxSize()
            # Do calculations
            CalculatePoleAndBox(poleLength, boxLength, boxWidth)
        elif userChoice == 'w':
            # Get the users information
            poleLength, maxLength = GetPoleAndMaxSize()
            # Do calculations
            CalculatePoleAndMax(poleLength, maxLength)
        elif userChoice == 'i':
            # Get the users information
            poleLength = GetPoleSize()
            # Do calculations
            FindSmallestBox(poleLength)
        else:
            exit()

        # Does the user want to try another calculation    
        tryAgain = input('Try another pole Y/N? =>')
        tryAgain = tryAgain.lower()
        
main()
