
def ShowMenu():
    ''' This Function will display a menu for the user to choose whether determine if they
    can get a fishing pole on the bus or to exit the program. '''

    answer = 'd'     
    print('(D)oes fishing pole fit in my box?')
    print('(W)hat size box will get my fishing pole on the bus?')
    print('(I) need to know what smallest box my fishing pole can fit in.')
    print('(E)xit program.')
    choice = input('(D/W/I/E) => ')
    choice = choice.lower()

    return choice

def GetPoleAndBoxSize():
    ''' This Function  will ask the user for the length of the pole, height of
    the box and the width of thebox and then returns these values.'''
    
    print('Lets determine if you can delever the pole.')

    poleLength = int(input('What is the length of your pole? '))
    boxLength = int(input('What is the box length? '))
    boxWidth = int(input('What is the box width? '))

    return poleLength, boxLength, boxWidth

def GetPoleAndMaxSize():
    ''' This Function  will ask the user for the length of the pole,
    and the max height that the box can be and return the values.'''
    
    print('Lets determine if you can delever the pole.')

    poleLength = int(input('What is the length of the pole? '))
    maxLength = int(input('What is the max length the box can be? '))

    return poleLength, maxLength

def GetPoleSize():
    ''' This Function  will ask the user for the length of the pole.
    and return that value.'''
    
    print('Lets determine if you can delever the pole.')

    poleLength = int(input('What is the length of the pole? '))

    return poleLength
