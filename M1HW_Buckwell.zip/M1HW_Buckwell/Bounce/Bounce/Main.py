# CSC221
# M1HW_Buckwell
# Goal: [Silver]

"""
Author: William Buckwell
This program determines how far a ball travels down and back to its apex given,
the height of the first drop and the number of times it bounces.
"""

def main():
    """
    This determines how far a ball has traveled (Fall + Raise) from the height
    and bounces
    """
    
    print('This prgram determines how far a bouncing ball travels')

    numBounces = int(input('How many does should the ball bounce? '))
    height = float(input('How high does the ball start from? (in feet) '))

    count = 1
    totalDistance = 0

    # Recover is how high the ball comes back up, this is the new height
    while count <= numBounces:
        recover = height * .6
        totalDistance = totalDistance + height + recover
        height = recover

        print('Bounce {}. It traveled {} feet'.format(count, totalDistance))

        count = count + 1

    

if __name__ == "__main__":
    main()
