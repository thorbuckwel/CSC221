import math
import fractions

# CSC221
# M1HW_Buckwell
# Goal: [Bronze}

"""
Author: William Buckwell
This program displays the Diameter, Circumference, Serface Area,
and the Volume of a Sphere from just the radius
"""

def main():
    """
    First get the radius from the user. After this determine the diameter
    circumference, Surface Area, and Volume. Next display the results to
    the user
    """
    
    print('Welcome to Sphere information program')
    radius = float(input('What is the Radius of the Sphere? '))

    diameter = radius * 2
    circumference = math.pi * diameter
    surfArea = math.pi * pow(diameter, 2)

    # This uses the Fraction function from fractions 
    volume =  (fractions.Fraction(1, 6) * math.pi) * pow(diameter, 3)

    print('The Diameter is ', diameter)
    print('The Circumference is ', circumference)
    print('The Surface Area is ', surfArea)
    print('The Volume is ', volume)

if __name__ == "__main__":
    main()
