# CSC221
# M1HW_Buckwell
# Goal: [Bronze]

"""
Author: William Buckwell
This program ask the user for hourly wage, regular hours and overtime hours,
then displays the employees weekly earnings
"""

def main():
    """
    Get the users hourly wage and their hours worked. This will be used to
    determine their regular pay. Next get the overtime hours. Overtime is
    calculate overtime hours times (hourlyPay times 1.5). TotalPay is regPay
    plus overtimePay. Display the results.
    """
    
    print('This program will figure out your pay for the week.')

    hourlyPay = float(input('What do you make hourly? '))
    regHours = int(input('Enter nearest whole hours worked: '))
    overtimeHours = int(input('Enter nearest whole hours of over time: '))

    regPay = hourlyPay * regHours
    overtimePay = overtimeHours * (hourlyPay * 1.5)

    totalPay = regPay + overtimePay

    print('Your pay for the week is $', totalPay)

if __name__ == "__main__":
    main()
