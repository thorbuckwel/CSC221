import math
import fractions

# CSC221
# M1HW_Buckwell
# Goal: [Gold]

"""
Author: William Buckwell
This program ask the user for hourly wage, regulare hours and overtime hours,
then displays the employees weekly earnings
"""

def main():
    """
    This program will use the Gottfried Leibniz Method get the approximate pi
    """
    
    denominatorList =[] # Used to hold all denominators
    demominator = 0
    count = 1
    calcPi = 0

    # Let the user to determine the number of iterations
    rounds = int(input('How many iterations? '))

    # Loop through the rounds to load the correct denominators
    while count <= rounds:
        if count == 1: # First iteration of the formula is 1, not a denominator
            count = count + 1
        elif count == 2: # The Second will be denominater of 3
            denominatorList.append(3)
            denominator = 3
            count = count + 1
        else: # Each iteration will be the denominator plus 2
            denominatorList.append(denominator + 2)
            denominator = denominator + 2
            count = count + 1

    count = 1 

    """
    Now to do the math, in the formula each iteration changes the operator,
    the first operator is - and then +.
    """
    while count <= rounds:
        if count == 1:
            calcPi = 1.0 # This will help set the result as a float
            count = count + 1
        elif count % 2 == 0: # If count is even then -
            calcPi = calcPi - fractions.Fraction(1, denominatorList[count - 2])
            count = count + 1
        else: # If count is odd then +
            calcPi = calcPi + fractions.Fraction(1, denominatorList[count - 2])
            count = count + 1

    calcPi = calcPi * 4 

    # show results
    print('Pi is {}'.format(calcPi))
    
if __name__ == "__main__":
    main()
