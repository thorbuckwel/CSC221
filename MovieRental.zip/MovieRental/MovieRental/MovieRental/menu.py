# -*- coding: utf-8 -*-
"""
Created on Thu Oct 25 13:00:45 2018

@author: buckwelw5455
"""

def DisplayMenu():
    print('Choose from the options below!')
    print('------------------------------')
    print('1. Available Movies')
    print('2. Add rental to cart')
    print('3. Remove rental from cart')
    print('4. Display cart')
    print('5. Rent whats in cart')
    print('6. Exit')
    
    choice = int(input('Please choose => '))
    
    return choice