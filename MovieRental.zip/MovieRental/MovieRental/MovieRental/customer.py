# -*- coding: utf-8 -*-
from rental import *
"""
Created on Thu Oct 25 13:01:21 2018

@author: buckwelw5455
"""
class Customer:
    def __init__(self, name, email, number):
        self.name = name
        self.email = email
        self.number = number
        self.cartList = []
        
def DisplayStatement(self):
    total = 0
    
    for rental in self.cartList:
        rental = rental.GetRentedCost(self)
        #total = total + float(rental.GetRentedCost())
        print(total)
        
        
