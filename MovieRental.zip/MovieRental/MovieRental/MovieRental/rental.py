# -*- coding: utf-8 -*-
"""
Created on Thu Oct 25 13:01:12 2018

@author: buckwelw5455
"""
class Rental:
    def __init__(self, movie, rentedDays):
        self.movie = movie
        self.rentedDays = rentedDays
        
    def GetRentedCost(self):
        cost = self.movie.price * self.rentedDays
        return cost
