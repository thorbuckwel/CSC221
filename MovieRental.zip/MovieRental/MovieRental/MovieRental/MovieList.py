# -*- coding: utf-8 -*-
import csv
from movie import *
"""
Created on Thu Oct 25 13:28:57 2018

@author: buckwelw5455
"""
MovieList = []

def LoadMovieList():
    with open('movies.csv', newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=',', quotechar='|')
        for row in reader:
            MovieList.append(Movie(row[0],row[1],row[2]))
            
def DisplayMovies():
    for movie in MovieList:
        print(movie.title, movie.price, movie.movieType)
    print('')