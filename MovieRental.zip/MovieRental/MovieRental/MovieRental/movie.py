# -*- coding: utf-8 -*-
"""
Created on Thu Oct 25 13:00:57 2018

@author: buckwelw5455
"""
class Movie:
    def __init__(self, title, price, movietype):
        self.title = title
        self.price = price
        self.movieType = movietype
