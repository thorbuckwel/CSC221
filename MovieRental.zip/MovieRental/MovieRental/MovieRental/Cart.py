# -*- coding: utf-8 -*-
from MovieList import *
from rental import *
"""
Created on Thu Oct 25 16:11:59 2018

@author: buckwelw5455
"""

def AddMovie(customer):
    another = True
    
    while another == True:
        DisplayMovies()
        movieTitle = input('Type movie title. => ')
    
        for movie in MovieList:
            if movie.title == movieTitle:
                ConvertToRental(movie, customer)
            
        for rental in customer.cartList:
            print(rental.movie.title, rental.rentedDays,'days')
        print('')
            
        test = input('Want another movie? Y/N => ')
        
        if test == 'N':
            another = False
            
def ConvertToRental(movie, customer):
    days = int(input('How many days do you want the movie => '))
    
    customer.cartList.append(Rental(movie,days))

def RemoveRental(customer):
    another = True
    
    DisplayCart(customer)
    
    while another == True:
        rentalMovie = input('Which rental do you want to remove? => ')
    
        for rental in customer.cartList:
            if rental.movie.title == rentalMovie:
                customer.cartList.remove(rental)
            
            DisplayCart(customer)
            
        another = input('Remove another Rental? Y/N => ')
        
        if another == 'N':
            another = False
            
def DisplayCart(customer):
    for rental in customer.cartList:
        print(rental.movie.title, rental.rentedDays,'days')
    print('')
        
    
    
    
    
    