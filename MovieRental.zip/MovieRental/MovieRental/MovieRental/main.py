# -*- coding: utf-8 -*-
from menu import *
from MovieList import *
from customer import *
from Cart import *
"""
Created on Thu Oct 25 13:00:34 2018

@author: buckwelw5455
"""

def main():
    keepGoing = True
    LoadMovieList()
    currentCustomer = Customer('Thor','@com','9991111') 
    
    while keepGoing == True:
        choice = DisplayMenu()
        
        if choice == 1:
            DisplayMovies()
        elif choice == 2:
            AddMovie(currentCustomer)
        elif choice == 3:
            RemoveRental(currentCustomer)
        elif choice == 4:
            DisplayCart(currentCustomer)
        elif choice == 5:
            print('5')
            DisplayStatement(currentCustomer)
        elif choice == 6:
            keepGoing = False
        else:
            print('')
            print('Not a valid choice!')
            print('')
    
    
if __name__ == "__main__":
    main()
