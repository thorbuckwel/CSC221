from arrays import Array

'''
    This displays the menu
'''
def menu():
    print('')
    print('1. Load student files.')
    print('2. List all students.')
    print('3. List students by program')
    print('4. Exit Program')
    print('Choose 1,2,3 or 4')
    print('')

'''
    This function simply steps through the array and displays each student
'''
def displayStudents(students):
    count = 0
    for student in students:
        if count != 0:
            print(student)
        count = count + 1

'''
    This function is not working as the program istructions intend for it to
    work.

    First for some reason the new array I created to hold students with their
    new program property is not regonized in the for loops when I go to compare
    the student.program, it says student does not have that.

    Second the book is real confusing on how to remove something from the array
    because I wanted to remove the first line.

    However I did get it to meet almost all of the requirments. On the next
    iteration I will do some refactoring since I do use the for loop alot
    throughout this whole program.
'''
def displayByProgram(students):
    studentPrograms = Array(11)
    count = 0
    
    #for student in students:
        #if count != 0:
            #student.program = student.convertProgram(student.program)
           # studentPrograms.__setitem__(count - 1, student)                        
        #count = count + 1
    
    print('Compuer Programming & Development')

    for student in students:
        if student.program == 'A25590C':
            print(' ', student.firstName, student.lastName)

    print('Systems Security & Analysis')

    for student in students:
        if student.program == 'A25590S':
            print(' ', student.firstName, student.lastName)

    print('Network Management')

    for student in students:
        if student.program == 'A25590N':
            print(' ', student.firstName, student.lastName)
    
    
