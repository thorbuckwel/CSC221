import csv 
from arrays import Array

'''
    I built the class here because I was having a hard time getting it to
    see the class if it was in its own file.
'''
class Student:

    def __init__(self,studentID,firstName,lastName,program,startDate,advisor,recentTerm,gpa):
        self.studentID = studentID
        self.firstName = firstName
        self.lastName = lastName
        self.startDate = startDate
        self.program = program
        self.advisor = advisor
        self.recentTerm = recentTerm
        self.gpa = gpa

    # Used to display the object
    def __str__(self):
        return 'Id: %s, First Name: %s, Last Name: %s, Started: %s, Program: %s, Advisor: %s, Recent Term: %s, GPS: %s' % (self.studentID,self.firstName,self.lastName,self.startDate,self.program,self.advisor,self.recentTerm,self.gpa)

    # Used to convert the code to a readable string
    def convertProgram(self, program):
        if program == 'A25590C':
            return 'Computer Programming & Development'
        elif program == 'A25590S':
            return 'Systems Security & Analysis'
        elif program == 'A25590N':
            return 'Network Management'
'''
    This function will load in the csv file then create an object and then
    add it to the array. It will then return the array so it can be used
    in other parts of the program
'''
def BuildArray():
    index = 0
    students = Array(11)
    studentFile = csv.reader(open('student_advisees_testdata.csv', newline = ''), delimiter = ',', quotechar= '|')

    for row in studentFile:
        student = Student(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row [7])
        students.__setitem__(index, student)
        index = index + 1
        

    return students
