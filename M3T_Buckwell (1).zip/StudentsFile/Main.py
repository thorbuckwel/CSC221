from StandardMessages import *
from ArrayBuilder import *
from arrays import Array

# CSC221
# M3T_Buckwell
# Goal: [Bronze | Silver | Gold]
"""
Created on Sat Oct 13 08:21:57 2018
This program will build and list student by diffrent filters

"""

def main():
    stop = 'n'
    students = ''

    # Loop to keep the program going
    while stop == 'n':
        menu()
        userInput = input('')

        # Determine what the user wants to do
        if userInput == '1':
            students = BuildArray()
        elif userInput == '2':
            if students == '':
                print('The student list has not been created!')
            else:
                displayStudents(students)
        elif userInput == '3':
            if students == '':
                print('The student list has not been created!')
            else:
                displayByProgram(students)
        else:
            stop = 'y'
            
if __name__ == "__main__":
    main()
